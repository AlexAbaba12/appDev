using System;

class MemoryGame
{
    int[,] cards = new int[4, 4];
    bool[,] faceUp = new bool[4, 4];
    Random rand = new Random();

    public MemoryGame()
    {
        InitializeCards();
        ShuffleCards();
    }

    void InitializeCards()
    {
        int value = 1;
        int count = 0;

        for (int i = 0; i < 4; i++)
        {
            for (int j = 0; j < 4; j++)
            {
                cards[i, j] = value;
                count++;

                if (count == 2)
                {
                    value++;
                    count = 0;
                }

                faceUp[i, j] = false;
            }
        }
    }

    void ShuffleCards()
    {
        for (int i = 0; i < 100; i++)
        {
            int r1 = rand.Next(4);
            int c1 = rand.Next(4);
            int r2 = rand.Next(4);
            int c2 = rand.Next(4);

            int temp = cards[r1, c1];
            cards[r1, c1] = cards[r2, c2];
            cards[r2, c2] = temp;
        }
    }

    void DisplayBoard()
    {
        Console.WriteLine("\nBoard:");

        for (int i = 0; i < 4; i++)
        {
            for (int j = 0; j < 4; j++)
            {
                if (faceUp[i, j])
                    Console.Write(cards[i, j] + " ");
                else
                    Console.Write("* ");
            }
            Console.WriteLine();
        }
    }

    public void Play()
    {
        int matches = 0;

        while (matches < 8)
        {
            DisplayBoard();

            Console.Write("Enter first card row (0-3): ");
            int r1 = int.Parse(Console.ReadLine());

            Console.Write("Enter first card column (0-3): ");
            int c1 = int.Parse(Console.ReadLine());

            faceUp[r1, c1] = true;
            DisplayBoard();

            Console.Write("Enter second card row (0-3): ");
            int r2 = int.Parse(Console.ReadLine());

            Console.Write("Enter second card column (0-3): ");
            int c2 = int.Parse(Console.ReadLine());

            faceUp[r2, c2] = true;
            DisplayBoard();

            if (cards[r1, c1] == cards[r2, c2])
            {
                Console.WriteLine("Match found!");
                matches++;
            }
            else
            {
                Console.WriteLine("Not a match!");

                faceUp[r1, c1] = false;
                faceUp[r2, c2] = false;
            }

            Console.WriteLine("Press Enter to continue...");
            Console.ReadLine();

            for (int i = 0; i < 30; i++)
                Console.WriteLine();
        }

        Console.WriteLine("Congratulations! You matched all cards.");
    }
}

class Program
{
    static void Main()
    {
        MemoryGame game = new MemoryGame();
        game.Play();
    }
}


