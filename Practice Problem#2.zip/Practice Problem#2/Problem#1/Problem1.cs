using System;

class Student
{
    private string name;
    private int totalScore;
    private int quizCount;

    // Constructor
    public Student(string studentName)
    {
        name = studentName;
        totalScore = 0;
        quizCount = 0;
    }

    // get_name()
    public string GetName()
    {
        return name;
    }

    // add_quiz(int score)
    public void AddQuiz(int score)
    {
        totalScore += score;
        quizCount++;
    }

    // get_total_score()
    public int GetTotalScore()
    {
        return totalScore;
    }

    // get_average_score()
    public double GetAverageScore()
    {
        if (quizCount == 0)
            return 0;

        return (double)totalScore / quizCount;
    }
}

class Program
{
    static void Main()
    {
        Student student1 = new Student("Alex");

        student1.AddQuiz(10);
        student1.AddQuiz(8);
        student1.AddQuiz(9);

        Console.WriteLine("Student Name: " + student1.GetName());
        Console.WriteLine("Total Score: " + student1.GetTotalScore());
        Console.WriteLine("Average Score: " + student1.GetAverageScore());
    }
}
