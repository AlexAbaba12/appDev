using System;

class DistinctCounter
{
    static void Main()
    {
        int[] data = { 1, 7, 2, 4, 2, 3, 8, 4, 6, 4, 4, 7 };

        int[] count = new int[11]; // values 0–10

        // Count occurrences
        foreach (int num in data)
        {
            count[num]++;
        }

        Console.WriteLine("Distinct Number Counts:");

        for (int i = 0; i <= 10; i++)
        {
            if (count[i] > 0)
            {
                Console.WriteLine(i + " occurred " + count[i] + " times");
            }
        }

        Console.WriteLine("\nTotal values entered: " + data.Length);
    }
}


