using System;

class CoinToss
{
    static Random rand = new Random();

    //Method flip()
    static int Flip()
    {
        return rand.Next(0,2); //0=tails, 1=heads
    }
    static void Main()
    {
        int heads = 0;
        int tails = 0;

        for (int i = 0; i < 80; i++)
        {
            int result = Flip();

            if (result == 1)
            {
                Console.WriteLine("Heads");
                heads++;
            }
            else
            {
                Console.WriteLine("Tails");
                tails++;
            }
        }

        Console.WriteLine("\nResults:");

        Console.WriteLine("Heads:");
        for (int i = 0; i < heads; i++)
        {
            Console.Write("*");
        }

        Console.WriteLine("Tails:");
        for (int i = 0; i < tails; i++)
        {
            Console.Write("*");
        }
        double headsPercent =(heads / 80.0)*100;
        double tailsPercent = (tails / 80.0)*100;

        Console.WriteLine("Heads" + headsPercent + "%");
        Console.WriteLine("Tails" + tailsPercent + "%");
    }
}