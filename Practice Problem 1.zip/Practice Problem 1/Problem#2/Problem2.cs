using System;

class BinarySearch
{
    static void Main()
    {
        int[] numbers = {12, 5, 8, 20, 3, 15, 7, 1, 9, 11, 4, 6, 18, 14, 2};

        //Sort the Array
        Array.Sort(numbers);

        Console.WriteLine("Sorted Array:");
        foreach (int num in numbers)
        {
            Console.Write(num + " ");
        }
        Console.WriteLine("\n");

        //Search for value
        Console.Write("Enter a number to search: ");
        int search = Convert.ToInt32(Console.ReadLine());

        int index = Array.BinarySearch(numbers, search);

        if (index>= 0)
        {
            Console.WriteLine("Value found at index: " + index);
        }
        else
        {
            Console.WriteLine("Value not found in the array.");
        }
    }
}