using System;

class CoinToss
{
    static Random rand = new Random();

    static int Flip()
    {
        return rand.Next(0, 2); // 0 = Tails, 1 = Heads
    }

    static void Main()
    {
        int heads = 0;
        int tails = 0;

        for (int i = 0; i < 80; i++)
        {
            int result = Flip();

            if (result == 1)
                heads++;
            else
                tails++;
        }

        Console.Write("Heads: ");
        for (int i = 0; i < heads; i++)
            Console.Write("*");

        Console.WriteLine();

        Console.Write("Tails: ");
        for (int i = 0; i < tails; i++)
            Console.Write("*");

        Console.WriteLine();

        Console.WriteLine("Heads: " + (heads / 80.0 * 100) + "%");
        Console.WriteLine("Tails: " + (tails / 80.0 * 100) + "%");
    }
}

