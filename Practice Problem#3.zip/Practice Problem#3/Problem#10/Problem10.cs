using System;

class Program
{
    static void Main()
    {
        int[] numbers = { 0, 1, 0, 3, 12 };

        int index = 0;

        for (int i = 0; i < numbers.Length; i++)
        {
            if (numbers[i] != 0)
            {
                numbers[index] = numbers[i];
                index++;
            }
        }

        while (index < numbers.Length)
        {
            numbers[index] = 0;
            index++;
        }

        Console.Write("Modified Array: ");

        foreach (int num in numbers)
        {
            Console.Write(num + " ");
        }
    }
}
