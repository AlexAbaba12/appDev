using System;

class Program
{
    static void Main()
    {
        int[] arr = {4,1,1,4,2,3,4,4,1,2,4,9,3};

        int most = arr[0];
        int maxCount = 0;

        for (int i = 0; i < arr.Length; i++)
        {
            int count = 0;

            for (int j = 0; j < arr.Length; j++)
            {
                if (arr[i] == arr[j])
                    count++;
            }

            if (count > maxCount)
            {
                maxCount = count;
                most = arr[i];
            }
        }

        Console.WriteLine(most + " (" + maxCount + " times)");
    }
}
