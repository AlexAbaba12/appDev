using System;

class Program
{
    static void Main()
    {
        Console.Write("Enter size of arrays: ");
        int n = int.Parse(Console.ReadLine());

        int[] arr1 = new int[n];
        int[] arr2 = new int[n];

        Console.WriteLine("Enter first array:");
        for (int i = 0; i < n; i++)
            arr1[i] = int.Parse(Console.ReadLine());

        Console.WriteLine("Enter second array:");
        for (int i = 0; i < n; i++)
            arr2[i] = int.Parse(Console.ReadLine());

        bool equal = true;

        for (int i = 0; i < n; i++)
        {
            if (arr1[i] != arr2[i])
            {
                equal = false;
                break;
            }
        }

        Console.WriteLine(equal ? "Arrays are equal" : "Arrays are NOT equal");
    }
}
