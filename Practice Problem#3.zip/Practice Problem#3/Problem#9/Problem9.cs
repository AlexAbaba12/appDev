using System;

class Program
{
    static void Main()
    {
        int[] arr = new int[5];

        Console.WriteLine("Enter 5 numbers:");

        for (int i = 0; i < 5; i++)
            arr[i] = int.Parse(Console.ReadLine());

        int missing = 1;

        while (true)
        {
            bool found = false;

            foreach (int num in arr)
            {
                if (num == missing)
                {
                    found = true;
                    break;
                }
            }

            if (!found)
                break;

            missing++;
        }

        Console.WriteLine("First Missing Positive Integer: " + missing);
    }
}
