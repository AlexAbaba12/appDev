using System;

class Program
{
    static void Main()
    {
        Console.Write("Enter N (less than 20): ");
        int n = int.Parse(Console.ReadLine());

        for (int row = 1; row <= n; row++)
        {
            for (int col = 1; col <= n; col++)
            {
                Console.Write((row + col - 1) + " ");
            }

            Console.WriteLine();
        }
    }
}
