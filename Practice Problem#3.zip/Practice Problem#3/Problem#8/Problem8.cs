using System;

class Program
{
    static void Main()
    {
        int[] numbers = { -1, 0, 1, 2, -1, -4 };

        Array.Sort(numbers);

        for (int i = 0; i < numbers.Length - 2; i++)
        {
            for (int j = i + 1; j < numbers.Length - 1; j++)
            {
                for (int k = j + 1; k < numbers.Length; k++)
                {
                    if (numbers[i] + numbers[j] + numbers[k] == 0)
                    {
                        Console.WriteLine("[" + numbers[i] + ", " + numbers[j] + ", " + numbers[k] + "]");
                    }
                }
            }
        }
    }
}
