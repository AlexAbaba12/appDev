using System;

class Program
{
    static void Main()
    {
        Console.Write("Enter N: ");
        int n = int.Parse(Console.ReadLine());

        int a = 0, b = 1, sum = 0;

        for (int i = 0; i < n; i++)
        {
            sum += a;
            int temp = a + b;
            a = b;
            b = temp;
        }

        Console.WriteLine("Sum: " + sum);
    }
}

